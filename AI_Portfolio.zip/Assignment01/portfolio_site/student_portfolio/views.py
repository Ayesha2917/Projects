from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from .models import Profile, Project
from django.core.mail import EmailMessage
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from django.template.loader import render_to_string
from django.contrib.auth.tokens import default_token_generator
from django.core.paginator import Paginator
from django.db.models import Q


def home(request):
    return redirect('login')


def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        if User.objects.filter(email=email).exists():
            messages.error(request, 'Email already registered.')
            return redirect('register')
        user = User.objects.create_user(username=username, email=email, password=password)
        user.is_active = False
        user.save()

        # Send verification email
        token = default_token_generator.make_token(user)
        uid = urlsafe_base64_encode(force_bytes(user.pk))
        link = request.build_absolute_uri(f'/verify/{uid}/{token}/')
        mail_subject = 'Verify your email'
        message = render_to_string('verify_email.html', {
            'user': user,
            'link': link
        })
        email_message = EmailMessage(mail_subject, message, to=[email])
        email_message.send()

        messages.success(request, 'Check your email to verify your account.')
        return redirect('login')
    return render(request, 'register.html')


def verify_email(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except:
        user = None
    if user and default_token_generator.check_token(user, token):
        user.is_active = True
        user.save()
        user.profile.is_verified = True
        user.profile.save()
        messages.success(request, 'Email verified. You can now login.')
    else:
        messages.error(request, 'Verification link is invalid.')
    return redirect('login')


def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            if user.profile.is_verified:
                login(request, user)
                return redirect('profile')
            else:
                messages.warning(request, 'Please verify your email first.')
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'login.html')


def logout_view(request):
    logout(request)
    return redirect('login')


@login_required
def profile(request):
    if request.method == 'POST':
        profile = request.user.profile

        # Resume upload
        resume = request.FILES.get('resume')
        if resume:
            if resume.name.endswith('.pdf') and resume.size <= 2 * 1024 * 1024:
                profile.resume = resume
            else:
                messages.error(request, 'Resume must be a PDF and under 2MB.')

        # Profile picture upload
        profile_pic = request.FILES.get('profile_picture')
        if profile_pic:
            profile.profile_picture = profile_pic

        profile.save()
        return redirect('profile')

    query = request.GET.get('q')
    projects = Project.objects.filter(owner=request.user)
    if query:
        projects = projects.filter(Q(title__icontains=query) | Q(tech_stack__icontains=query))

    paginator = Paginator(projects, 5)
    page = request.GET.get('page')
    projects_page = paginator.get_page(page)

    context = {
        'profile': request.user.profile,
        'projects': projects_page
    }
    return render(request, 'profile.html', context)


@login_required
def add_project(request):
    if request.method == 'POST':
        Project.objects.create(
            owner=request.user,
            title=request.POST['title'],
            description=request.POST['description'],
            tech_stack=request.POST['tech_stack'],
            github_link=request.POST['github_link']
        )
        return redirect('profile')
    return render(request, 'add_project.html')

@login_required
def edit_project(request, project_id):
    project = get_object_or_404(Project, pk=project_id, owner=request.user)
    if request.method == 'POST':
        project.title = request.POST['title']
        project.description = request.POST['description']
        project.tech_stack = request.POST['tech_stack']
        project.github_link = request.POST['github_link']
        project.save()
        return redirect('profile')
    return render(request, 'edit_project.html', {'project': project})


@login_required
def delete_project(request, project_id):
    project = get_object_or_404(Project, pk=project_id, owner=request.user)
    project.delete()
    return redirect('profile')
