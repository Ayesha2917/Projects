from django.db import models
from django.contrib.auth.models import User

def resume_upload_path(instance, filename):
    return f'resumes/user_{instance.user.id}/{filename}'

def profile_pic_upload_path(instance, filename):
    return f'profile_pics/user_{instance.user.id}/{filename}'

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    profile_picture = models.ImageField(upload_to=profile_pic_upload_path, null=True, blank=True)
    resume = models.FileField(upload_to=resume_upload_path, null=True, blank=True)
    is_verified = models.BooleanField(default=False)

    def __str__(self):
        return self.user.username

class Project(models.Model):
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    description = models.TextField()
    tech_stack = models.CharField(max_length=255)
    github_link = models.URLField()

    def __str__(self):
        return f"{self.title} ({self.owner.username})"
