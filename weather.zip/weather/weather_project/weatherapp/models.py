from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    bio = models.TextField(blank=True)
    # Add more fields as needed

    def __str__(self):
        return f"{self.user.username} Profile"
from django.db import models

class WeatherData(models.Model):
    city = models.CharField(max_length=100)
    temperature = models.CharField(max_length=20)
    description = models.CharField(max_length=100)
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.city
