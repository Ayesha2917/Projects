from django.views.decorators.csrf import csrf_exempt
@csrf_exempt
def forecast(request):
    context = {}
    error = None
    forecast_data = []
    city = None
    if request.method == 'POST':
        city = request.POST.get('city', '').strip()
        if not city:
            error = "Please enter a city name."
        else:
            api_key = 'd6a22c3037a54a0ab4a105802252107'
            weather_url = f'https://api.weatherapi.com/v1/forecast.json?key={api_key}&q={city}&days=7'
            try:
                resp = requests.get(weather_url, timeout=8)
                if resp.status_code == 200:
                    data = resp.json()
                    # Parse 7-day forecast
                    for day in data.get('forecast', {}).get('forecastday', []):
                        forecast_data.append({
                            'date': day['date'],
                            'temp': f"{day['day']['avgtemp_c']}°C",
                            'maxtemp': f"{day['day']['maxtemp_c']}°C",
                            'mintemp': f"{day['day']['mintemp_c']}°C",
                            'desc': day['day']['condition']['text'],
                            'icon': f"https:{day['day']['condition']['icon']}",
                            'humidity': f"{day['day']['avghumidity']}%",
                            'wind': f"{day['day']['maxwind_kph']} kph"
                        })
                else:
                    error = "Could not fetch forecast data for this city."
            except Exception:
                error = "Could not connect to forecast service."
    context = {
        'city': city,
        'forecast_data': forecast_data,
        'error': error
    }
    return render(request, 'weatherapp/forecast.html', context)
def logout_view(request):
    logout(request)
    return redirect('/login/')

from django.shortcuts import render, redirect
from .models import WeatherData, Profile
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib import messages
from django.core.mail import send_mail
from django.conf import settings
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str
from django.template.loader import render_to_string
from django.contrib.auth.tokens import default_token_generator
from .forms import RegisterForm, LoginForm
import requests


def home(request):
    if not request.user.is_authenticated:
        return redirect(f"/login/?next={request.path}")
    context = {}
    city = None
    api_key = 'd6a22c3037a54a0ab4a105802252107'
    if request.method == 'POST':
        city = request.POST.get('city')
    else:
        city = None

    if city:
        weather_url = f'https://api.weatherapi.com/v1/forecast.json?key={api_key}&q={city}&days=7'
        try:
            resp = requests.get(weather_url, timeout=8)
            if resp.status_code == 200:
                data = resp.json()
                current = data.get('current', {})
                location = data.get('location', {})
                context.update({
                    'city': city,
                    'country': location.get('country', ''),
                    'temp': f"{current.get('temp_c', 'N/A')}°C",
                    'desc': current.get('condition', {}).get('text', ''),
                    'humidity': f"{current.get('humidity', 'N/A')}%",
                    'wind': f"{current.get('wind_kph', 'N/A')} kph"
                })
                # Save to recent searches only for POST
                if request.method == 'POST':
                    weather = WeatherData.objects.create(city=city, temperature=context['temp'], description=context['desc'])
                    weather.save()
                # Extract 7-day forecast data for Chart.js
                forecast_days = data.get('forecast', {}).get('forecastday', [])
                labels = [day['date'] for day in forecast_days]
                temperatures = [day['day']['avgtemp_c'] for day in forecast_days]
                context['labels'] = labels
                context['temperatures'] = temperatures
            else:
                context.update({
                    'city': city,
                    'country': '',
                    'temp': "N/A",
                    'desc': "Not found",
                    'humidity': 'N/A',
                    'wind': 'N/A',
                    'labels': [],
                    'temperatures': []
                })
        except Exception:
            context.update({
                'city': city,
                'country': '',
                'temp': "N/A",
                'desc': "Not found",
                'humidity': 'N/A',
                'wind': 'N/A',
                'labels': [],
                'temperatures': []
            })
    return render(request, 'weatherapp/home.html', context)

def register(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.is_active = False
            user.save()
            Profile.objects.create(user=user)
            # Send verification email
            token = default_token_generator.make_token(user)
            uid = urlsafe_base64_encode(force_bytes(user.pk))
            activation_link = request.build_absolute_uri(f"/activate/{uid}/{token}/")
            subject = "Activate your account"
            message = f"Hi {user.username},\nPlease click the link to activate your account: {activation_link}"
            send_mail(subject, message, settings.DEFAULT_FROM_EMAIL, [user.email])
            messages.success(request, "Check your email to activate your account.")
            return redirect("login")
    else:
        form = RegisterForm()
    return render(request, "weatherapp/register.html", {"form": form})

def activate(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None
    if user and default_token_generator.check_token(user, token):
        user.is_active = True
        user.save()
        messages.success(request, "Account activated. You can now log in.")
        return redirect("login")
    else:
        messages.error(request, "Activation link is invalid!")
        return redirect("register")

def login_view(request):
    if request.method == "POST":
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data["username"]
            password = form.cleaned_data["password"]
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                next_url = request.POST.get('next') or request.GET.get('next')
                if next_url:
                    return redirect(next_url)
                return redirect("home")
            else:
                messages.error(request, "Invalid credentials or account not activated.")
    else:
        form = LoginForm()
    return render(request, "weatherapp/login.html", {"form": form})

def profile(request):
    if not request.user.is_authenticated:
        return redirect(f"/login/?next={request.path}")
    profile = Profile.objects.get(user=request.user)
    # Get recent searches for this user (last 5)
    recent_searches = WeatherData.objects.filter(city__isnull=False).order_by('-date')[:5]
    return render(request, "weatherapp/profile.html", {
        "profile": profile,
        "recent_searches": recent_searches,
        "user": request.user
    })
