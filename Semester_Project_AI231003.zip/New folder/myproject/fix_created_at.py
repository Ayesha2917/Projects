from tasks.models import Task
from django.utils import timezone

def fix_created_at():
    for task in Task.objects.all():
        if task.created_at.date() != task.date:
            # Set created_at to the scheduled date at noon (or any time you want)
            task.created_at = timezone.make_aware(timezone.datetime.combine(task.date, timezone.datetime.min.time()))
            task.save()
    print('All old tasks have been updated!')

# Usage: Run this script with Django shell
# python manage.py shell < fix_created_at.py
