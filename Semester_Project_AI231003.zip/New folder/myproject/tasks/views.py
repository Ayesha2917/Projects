from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Task
from django.contrib.auth.models import User
from django.utils import timezone
from django.contrib.auth import authenticate, login
from django.contrib.auth import logout as auth_logout
from datetime import date, datetime, timedelta
from django.http import HttpResponse
from django.contrib import messages
from django import forms
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from django.core.files.storage import default_storage
from django.conf import settings
from django.db import models

# Profile model for user profile picture
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    profile_picture = models.ImageField(upload_to='profile_pics/', blank=True, null=True)

    def __str__(self):
        return self.user.username

# Profile picture form
class ProfilePicForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['profile_picture']

@login_required
def add_task(request):
    if request.method == 'POST':
        subject = request.POST.get('subject')
        topic = request.POST.get('topic')
        date_str = request.POST.get('date')
        due_date_str = request.POST.get('due_date')
        priority = request.POST.get('priority')
        try:
            date_obj = datetime.strptime(date_str, '%Y-%m-%d').date() if date_str else None
            due_date_obj = datetime.strptime(due_date_str, '%Y-%m-%d').date() if due_date_str else None
        except ValueError:
            date_obj = None
            due_date_obj = None
        if subject and topic and date_obj and due_date_obj and priority:
            Task.objects.create(
                user=request.user,
                subject=subject,
                topic=topic,
                date=date_obj,
                due_date=due_date_obj,
                priority=priority
            )
            return redirect('all_tasks')
    return render(request, 'tasks/add_task.html')

@login_required
def all_tasks(request):
    tasks = Task.objects.filter(user=request.user)
    subject = request.GET.get('subject')
    priority = request.GET.get('priority')
    completed = request.GET.get('completed')
    priorities = Task.objects.filter(user=request.user).values_list('priority', flat=True).distinct()
    if subject:
        tasks = tasks.filter(subject__icontains=subject)
    if priority:
        tasks = tasks.filter(priority=priority)
    if completed == 'true':
        tasks = tasks.filter(completed=True)
    elif completed == 'false':
        tasks = tasks.filter(completed=False)
    return render(request, 'tasks/all_tasks.html', {
        'tasks': tasks,
        'subject': subject,
        'priority': priority,
        'completed': completed,
        'priorities': priorities,
    })

@login_required
def edit_task(request, pk):
    task = get_object_or_404(Task, pk=pk, user=request.user)
    if request.method == 'POST':
        task.subject = request.POST.get('subject')
        task.topic = request.POST.get('topic')
        date_str = request.POST.get('date')
        due_date_str = request.POST.get('due_date')
        try:
            task.date = datetime.strptime(date_str, '%Y-%m-%d').date() if date_str else None
            task.due_date = datetime.strptime(due_date_str, '%Y-%m-%d').date() if due_date_str else None
        except ValueError:
            pass
        task.priority = request.POST.get('priority')
        task.save()
        return redirect('all_tasks')
    return render(request, 'tasks/edit_task.html', {'task': task})

@login_required
def delete_task(request, pk):
    task = get_object_or_404(Task, pk=pk, user=request.user)
    if request.method == 'POST':
        task.delete()
        return redirect('all_tasks')
    return render(request, 'tasks/delete_task.html', {'task': task})

@login_required
def complete_task(request, pk):
    task = get_object_or_404(Task, pk=pk, user=request.user)
    if request.method == 'POST':
        task.completed = True
        task.save()
        return redirect('all_tasks')
    return redirect('all_tasks')

@login_required
def dashboard(request):
    today = date.today()
    tasks = Task.objects.filter(user=request.user, due_date=today)
    completed_tasks = tasks.filter(completed=True).count()
    total_tasks = tasks.count()
    progress_percent = int((completed_tasks / total_tasks) * 100) if total_tasks > 0 else 0
    return render(request, 'tasks/dashboard.html', {
        'tasks': tasks,
        'completed_tasks': completed_tasks,
        'total_tasks': total_tasks,
        'progress_percent': progress_percent,
    })

def footer(request):
    return render(request, 'tasks/footer.html')

def home(request):
    return redirect('dashboard')

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        next_url = request.POST.get('next') or request.GET.get('next')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            if next_url and next_url != 'None':
                return redirect(next_url)
            return redirect('dashboard')
        else:
            error = 'Invalid username or password.'
            return render(request, 'tasks/login.html', {'error': error, 'next': next_url})
    else:
        next_url = request.GET.get('next', '')
        return render(request, 'tasks/login.html', {'next': next_url})

def logout_view(request):
    auth_logout(request)
    return redirect('login')

def navigation(request):
    return render(request, 'tasks/navigation.html')

def register(request):
    error = None
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')
        if not username or not password or not confirm_password:
            error = 'All fields are required.'
        elif password != confirm_password:
            error = 'Passwords do not match.'
        elif User.objects.filter(username=username).exists():
            error = 'Username already exists.'
        else:
            user = User.objects.create_user(username=username, password=password)
            login(request, user)
            return redirect('dashboard')
    return render(request, 'tasks/register.html', {'error': error})

@login_required
def task_detail(request, pk):
    task = get_object_or_404(Task, pk=pk, user=request.user)
    return render(request, 'tasks/task_detail.html', {'task': task})

def task_list(request):
    return render(request, 'tasks/task_list.html')

@login_required
def todays_tasks(request):
    today = date.today()
    tasks = Task.objects.filter(user=request.user, due_date=today)
    return render(request, 'tasks/todays_tasks.html', {'tasks': tasks})

def tomorrows_tasks(request):
    return render(request, 'tasks/tomorrows_tasks.html')

@login_required
def user_profile(request):
    user = request.user
    # Get or create profile
    profile, created = Profile.objects.get_or_create(user=user)
    pic_form = ProfilePicForm(instance=profile)
    pwd_form = PasswordChangeForm(user)
    pic_updated = False
    pwd_updated = False
    pic_removed = False
    if request.method == 'POST':
        if 'update_pic' in request.POST:
            pic_form = ProfilePicForm(request.POST, request.FILES, instance=profile)
            if pic_form.is_valid():
                pic_form.save()
                pic_updated = True
        elif 'remove_pic' in request.POST:
            if profile.profile_picture:
                profile.profile_picture.delete(save=True)
                pic_removed = True
        elif 'update_pwd' in request.POST:
            pwd_form = PasswordChangeForm(user, request.POST)
            if pwd_form.is_valid():
                user = pwd_form.save()
                update_session_auth_hash(request, user)
                pwd_updated = True
    return render(request, 'tasks/user_profile.html', {
        'user': user,
        'profile': profile,
        'pic_form': pic_form,
        'pwd_form': pwd_form,
        'pic_updated': pic_updated,
        'pwd_updated': pwd_updated,
        'pic_removed': pic_removed,
    })

def verify_email(request):
    return render(request, 'tasks/verify_email.html')

@login_required
def export_tasks_pdf(request):
    tasks = Task.objects.filter(user=request.user)
    return render(request, 'tasks/export_tasks_pdf.html', {'tasks': tasks, 'user': request.user})

@login_required
def analytics(request):
    user = request.user
    today = timezone.now().date()
    last_7_days = [today - timedelta(days=i) for i in range(6, -1, -1)]
    bar_labels = [d.strftime('%a') for d in last_7_days]
    bar_data = []
    for d in last_7_days:
        count = Task.objects.filter(user=user, created_at__date=d).count()
        bar_data.append(count)
    completed_count = Task.objects.filter(user=user, completed=True).count()
    incomplete_count = Task.objects.filter(user=user, completed=False).count()
    context = {
        'bar_labels': bar_labels,
        'bar_data': bar_data,
        'completed_count': completed_count,
        'incomplete_count': incomplete_count,
    }
    return render(request, 'tasks/analytics.html', context)

@login_required
def completed_tasks(request):
    tasks = Task.objects.filter(user=request.user, completed=True)
    return render(request, 'tasks/completed_tasks.html', {'tasks': tasks})

# Placeholder: You can implement PDF export logic here later
# def task_pdf(request, pk):
#     return HttpResponse(f"PDF export for task {pk}")

@login_required
def mark_completed(request, pk):
    task = get_object_or_404(Task, pk=pk, user=request.user)
    if request.method == 'POST':
        if not task.completed:
            task.completed = True
            task.save()
            messages.success(request, 'Task marked as completed!')
    return redirect('all_tasks')

@login_required
def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            messages.success(request, 'Your password was successfully updated!')
            return redirect('user_profile')
        else:
            messages.error(request, 'Please correct the error below.')
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'tasks/change_password.html', {'form': form})
