# gradebook/urls.py
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('', include('grades.urls')),  # This connects your app's URLs
]
