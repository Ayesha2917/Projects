 
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/teacher/', views.register_teacher, name='register_teacher'),
    path('register/student/', views.register_student, name='register_student'),
    path('login/teacher/', views.login_teacher, name='login_teacher'),
    path('login/student/', views.login_student, name='login_student'),
    path('logout/', views.user_logout, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),

    path('profile/teacher/', views.teacher_profile, name='teacher_profile'),
    path('profile/student/', views.student_profile, name='student_profile'),
    path('add-grade/', views.add_grade, name='add_grade'),
    path('student/<int:student_id>/', views.student_detail, name='student_detail'),
    path('student/<int:student_id>/update/', views.update_student, name='update_student'),
    path('student/<int:student_id>/delete/', views.delete_student, name='delete_student'),
    path('grade/<int:grade_id>/update/', views.update_grade, name='update_grade'),
    path('grade/<int:grade_id>/delete/', views.delete_grade, name='delete_grade'),
]
