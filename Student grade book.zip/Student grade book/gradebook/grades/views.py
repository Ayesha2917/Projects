# Teacher profile view
from django.contrib.auth.decorators import login_required

@login_required
def teacher_profile(request):
    profile = get_object_or_404(UserProfile, user=request.user)
    if not profile.is_teacher:
        return redirect('dashboard')
    teacher = get_object_or_404(Teacher, user=request.user)
    return render(request, 'grades/teacher_profile.html', {'teacher': teacher})

# Student profile view
@login_required
def student_profile(request):
    profile = get_object_or_404(UserProfile, user=request.user)
    if profile.is_teacher:
        return redirect('dashboard')
    student = get_object_or_404(Student, user=request.user)
    return render(request, 'grades/student_profile.html', {'student': student})

from django.http import HttpResponse
from django.contrib import messages
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import Student, Subject, Grade, UserProfile, Teacher

# --- Update/Delete Student and Grade Views ---
@login_required
def update_student(request, student_id):
    student = get_object_or_404(Student, id=student_id)
    if request.method == 'POST':
        student.user.username = request.POST['username']
        student.roll_no = request.POST['roll_no']
        student.class_name = request.POST['class_name']
        student.user.save()
        student.save()
        messages.success(request, 'Student updated successfully!')
        return redirect('dashboard')
    return render(request, 'grades/update_student.html', {'student': student})

@login_required
def delete_student(request, student_id):
    student = get_object_or_404(Student, id=student_id)
    if request.method == 'POST':
        student.user.delete()
        student.delete()
        messages.success(request, 'Student deleted successfully!')
        return redirect('dashboard')
    return render(request, 'grades/delete_student.html', {'student': student})

@login_required
def update_grade(request, grade_id):
    grade = get_object_or_404(Grade, id=grade_id)
    subjects = Subject.objects.all()
    if request.method == 'POST':
        subject_id = request.POST['subject']
        grade.subject = get_object_or_404(Subject, id=subject_id)
        grade.marks = request.POST['marks']
        grade.save()
        messages.success(request, 'Grade updated successfully!')
        return redirect('student_detail', student_id=grade.student.id)
    return render(request, 'grades/update_grade.html', {'grade': grade, 'subjects': subjects})

@login_required
def delete_grade(request, grade_id):
    grade = get_object_or_404(Grade, id=grade_id)
    student_id = grade.student.id
    if request.method == 'POST':
        grade.delete()
        messages.success(request, 'Grade deleted successfully!')
        return redirect('student_detail', student_id=student_id)
    return render(request, 'grades/delete_grade.html', {'grade': grade})

def home(request):
    return render(request, 'grades/home.html')




# Teacher registration





def register_teacher(request):
    error = None
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        full_name = request.POST['full_name']
        num_subjects = int(request.POST.get('num_subjects', 1))
        subject_ids = []
        if not username or not email or not password or not full_name:
            error = 'All fields are required.'
        elif User.objects.filter(username=username).exists():
            error = 'Username already exists.'
        elif User.objects.filter(email=email).exists():
            error = 'Email already exists.'
        else:
            name_parts = full_name.strip().split(' ', 1)
            first_name = name_parts[0]
            last_name = name_parts[1] if len(name_parts) > 1 else ''
            user = User.objects.create_user(username=username, password=password, email=email, first_name=first_name, last_name=last_name, is_active=True)
            UserProfile.objects.create(user=user, is_teacher=True)
            teacher = Teacher.objects.create(user=user, full_name=full_name)
            from .models import Subject
            for i in range(1, num_subjects + 1):
                subject_name = request.POST.get(f'subject_name_{i}')
                if subject_name:
                    subject, created = Subject.objects.get_or_create(name=subject_name)
                    subject_ids.append(subject.id)
            if subject_ids:
                teacher.subjects.set(subject_ids)
            from django.contrib import messages
            messages.success(request, 'Registration successful! Please log in.')
            return redirect('login_teacher')
    return render(request, 'grades/register_teacher.html', {'error': error})

# Student registration

def register_student(request):
    error = None
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        full_name = request.POST['full_name']
        password = request.POST['password']
        roll_no = request.POST['roll_no']
        class_name = request.POST['class_name']
        if not username or not email or not full_name or not password or not roll_no or not class_name:
            error = 'All fields are required.'
        elif User.objects.filter(username=username).exists():
            error = 'Username already exists.'
        elif User.objects.filter(email=email).exists():
            error = 'Email already exists.'
        else:
            name_parts = full_name.strip().split(' ', 1)
            first_name = name_parts[0]
            last_name = name_parts[1] if len(name_parts) > 1 else ''
            user = User.objects.create_user(username=username, password=password, email=email, first_name=first_name, last_name=last_name, is_active=True)
            UserProfile.objects.create(user=user, is_teacher=False)
            Student.objects.create(user=user, roll_no=roll_no, class_name=class_name)
            from django.contrib import messages
            messages.success(request, 'Registration successful! Please log in.')
            return redirect('login_student')
    return render(request, 'grades/register_student.html', {'error': error})







# Teacher login
def login_teacher(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user:
            try:
                profile = UserProfile.objects.get(user=user)
                if profile.is_teacher:
                    from .models import Teacher
                    if Teacher.objects.filter(user=user).exists():
                        login(request, user)
                        from django.contrib import messages
                        messages.success(request, 'Login successful!')
                        return redirect('dashboard')
            except UserProfile.DoesNotExist:
                pass
        from django.contrib import messages
        messages.error(request, 'Invalid credentials or not a teacher.')
        return render(request, 'grades/login_teacher.html')
    return render(request, 'grades/login_teacher.html')

# Student login
def login_student(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user:
            try:
                profile = UserProfile.objects.get(user=user)
                if not profile.is_teacher:
                    login(request, user)
                    from django.contrib import messages
                    messages.success(request, 'Login successful!')
                    return redirect('dashboard')
            except UserProfile.DoesNotExist:
                pass
        from django.contrib import messages
        messages.error(request, 'Invalid credentials or not a student.')
        return render(request, 'grades/login_student.html')
    return render(request, 'grades/login_student.html')

@login_required
def user_logout(request):
    logout(request)
    from django.contrib import messages
    messages.info(request, 'Logged out successfully.')
    return redirect('home')


@login_required
def dashboard(request):
    profile = get_object_or_404(UserProfile, user=request.user)
    if profile.is_teacher:
        # Get all unique class names
        class_names = Student.objects.values_list('class_name', flat=True).distinct().order_by('class_name')
        class_students = {}
        for class_name in class_names:
            class_students[class_name] = Student.objects.filter(class_name=class_name).order_by('roll_no')
        return render(request, 'grades/dashboard.html', {'class_students': class_students})
    else:
        student = get_object_or_404(Student, user=request.user)
        grades = Grade.objects.filter(student=student)
        return render(request, 'grades/dashboard.html', {'grades': grades})



# Remove add_student view (students self-register)

@login_required
def add_grade(request):
    # Only allow teachers to add grades
    profile = get_object_or_404(UserProfile, user=request.user)
    if not profile.is_teacher:
        return redirect('dashboard')

    teacher = get_object_or_404(Teacher, user=request.user)
    students = Student.objects.all()
    subjects = teacher.subjects.all()
    error = None

    if request.method == 'POST':
        student_id = request.POST.get('student')
        subject_id = request.POST.get('subject')
        marks = request.POST.get('marks')
        # Validate input
        if not student_id or not subject_id or not marks:
            error = 'All fields are required.'
        else:
            try:
                marks = float(marks)
                student = get_object_or_404(Student, id=student_id)
                subject = get_object_or_404(Subject, id=subject_id)
                Grade.objects.create(student=student, subject=subject, marks=marks)
                from django.contrib import messages
                messages.success(request, 'Grade added successfully!')
                return redirect('student_detail', student_id=student.id)
            except Exception as e:
                error = 'Invalid input. Please check your entries.'

    return render(request, 'grades/add_grade.html', {'students': students, 'subjects': subjects, 'error': error})

@login_required
def student_detail(request, student_id):
    student = get_object_or_404(Student, id=student_id)
    grades = Grade.objects.filter(student=student)
    return render(request, 'grades/student_detail.html', {'student': student, 'grades': grades})
