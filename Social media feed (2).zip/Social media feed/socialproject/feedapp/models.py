from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager

class StudentManager(BaseUserManager):
    def create_user(self, email, username, password=None):
        user = self.model(email=email, username=username)
        user.set_password(password)
        user.is_active = True
        user.save(using=self._db)
        return user

class Studentauth(AbstractBaseUser):
    email = models.EmailField(unique=True)
    username = models.CharField(max_length=50)
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']

    objects = StudentManager()

    def __str__(self):
        return self.email

class Profile(models.Model):
    user = models.OneToOneField(Studentauth, on_delete=models.CASCADE)
    bio = models.TextField(blank=True)
    profile_pic = models.ImageField(upload_to='profiles/', blank=True)
    followers = models.ManyToManyField(Studentauth, related_name='followers', blank=True)

    def get_profile_pic_url(self):
        if self.profile_pic:
            return self.profile_pic.url
        return '/static/feedapp/default.jpg'

class Post(models.Model):
    user = models.ForeignKey(Studentauth, on_delete=models.CASCADE)
    caption = models.TextField()
    image = models.ImageField(upload_to='posts/')
    created_at = models.DateTimeField(auto_now_add=True)
    likes = models.ManyToManyField(Studentauth, related_name='likes', blank=True)
