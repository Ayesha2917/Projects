from django.urls import path

from . import views

urlpatterns = [
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('register/', views.register, name='register'),
    path('', views.home, name='home'),
    path('profile/<int:user_id>/', views.profile, name='profile'),
    path('edit_profile/', views.edit_profile, name='edit_profile'),
    path('delete_profile_pic/', views.delete_profile_pic, name='delete_profile_pic'),
    path('follow/<int:user_id>/', views.follow_user, name='follow_user'),
    path('toggle-follow/<int:user_id>/', views.toggle_follow, name='toggle_follow'),
    path('followers/<int:user_id>/', views.followers_list, name='followers_list'),
    path('users/', views.all_users, name='all_users'),
    path('create_post/', views.create_post, name='create_post'),
    path('like/<int:post_id>/', views.like_post, name='like_post'),
    path('my_profile/', views.my_profile, name='my_profile'),
    path('delete_post/<int:post_id>/', views.delete_post, name='delete_post'),
    path('activate/<uidb64>/<token>/', views.activate_account, name='activate'),
]
