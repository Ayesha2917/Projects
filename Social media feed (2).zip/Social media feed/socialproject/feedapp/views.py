from django.utils.http import urlsafe_base64_decode
from django.contrib.auth.tokens import default_token_generator

def activate_account(request, uidb64, token):
    from .models import Studentauth
    try:
        uid = urlsafe_base64_decode(uidb64).decode()
        user = Studentauth.objects.get(pk=uid)
    except Exception:
        user = None

    if user and default_token_generator.check_token(user, token):
        user.is_active = True
        user.save()
        return render(request, 'activation_success.html')
    else:
        return render(request, 'activation_failed.html')
from django.core.mail import EmailMultiAlternatives
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_encode
from django.utils.encoding import force_bytes
from django.contrib.auth.tokens import default_token_generator

def send_verification_email(request, user):
    current_site = get_current_site(request)
    subject = 'Verify your email'
    uid = urlsafe_base64_encode(force_bytes(user.pk))
    token = default_token_generator.make_token(user)

    message = render_to_string('email_verification.html', {
        'user': user,
        'domain': current_site.domain,
        'uid': uid,
        'token': token,
    })

    email = EmailMultiAlternatives(
        subject,
        '',  # plain text body (optional)
        from_email=None,  # will use DEFAULT_FROM_EMAIL
        to=[user.email]
    )
    email.attach_alternative(message, "text/html")
    email.send(fail_silently=False)
from django.shortcuts import get_object_or_404

from django.views.decorators.http import require_POST

# Delete post view
@require_POST
def delete_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    if post.user == request.user:
        post.delete()
        messages.success(request, "Post deleted successfully.")
    else:
        messages.error(request, "You are not authorized to delete this post.")
    return redirect('profile', user_id=request.user.id)
def my_profile(request):
    if not request.user.is_authenticated:
        return redirect('login')

    profile = Profile.objects.get(user=request.user)

    if request.method == 'POST':
        bio = request.POST.get('bio', '')
        profile.bio = bio
        profile.save()
        from django.contrib import messages
        messages.success(request, "Bio updated successfully.")
        return redirect('my_profile')  # Redirect to show updated bio and avoid resubmission

    return render(request, 'feedapp/my_profile.html', {'profile': profile})
import os
from django.conf import settings
def delete_profile_pic(request):
    if not request.user.is_authenticated:
        return redirect('login')

    profile = Profile.objects.get(user=request.user)

    if profile.profile_pic:
        # Delete file from disk
        file_path = os.path.join(settings.MEDIA_ROOT, str(profile.profile_pic))
        if os.path.isfile(file_path):
            os.remove(file_path)
        # Clear from model
        profile.profile_pic = ''
        profile.save()

    from django.contrib import messages
    messages.success(request, "Profile picture removed.")
    return redirect('edit_profile')
def edit_profile(request):
    if not request.user.is_authenticated:
        return redirect('login')

    profile = Profile.objects.get(user=request.user)



    if request.method == 'POST':
        bio = request.POST.get('bio', '')
        profile.bio = bio  # Always update bio, even if empty

        # Handle profile pic upload
        if 'profile_pic' in request.FILES:
            profile.profile_pic = request.FILES['profile_pic']

        profile.save()
        from django.contrib import messages
        messages.success(request, "Profile updated successfully.")
        return redirect('my_profile')

    return render(request, 'feedapp/edit_profile.html', {'profile': profile})
def followers_list(request, user_id):
    if not request.user.is_authenticated:
        return redirect('login')

    user = Studentauth.objects.get(id=user_id)
    profile = Profile.objects.get(user=user)
    followers = profile.followers.all()

    return render(request, 'feedapp/followers_list.html', {
        'user_profile': user,
        'followers': followers,
    })
from django.http import HttpResponseRedirect
from django.urls import reverse
def toggle_follow(request, user_id):
    if not request.user.is_authenticated:
        return redirect('login')

    if request.user.id == user_id:
        from django.contrib import messages
        messages.error(request, "You cannot follow your own account.")
        return redirect('all_users')

    target_user = Studentauth.objects.get(id=user_id)
    target_profile = Profile.objects.get(user=target_user)

    if request.user in target_profile.followers.all():
        target_profile.followers.remove(request.user)
    else:
        target_profile.followers.add(request.user)

    return HttpResponseRedirect(request.META.get('HTTP_REFERER', reverse('all_users')))

def all_users(request):
    if not request.user.is_authenticated:
        return redirect('login')
    query = request.GET.get('q', '')
    users = Studentauth.objects.exclude(id=request.user.id)
    if query:
        users = users.filter(username__icontains=query)
    profiles = Profile.objects.filter(user__in=users).order_by('-user__id')
    context = {
        'profiles': profiles,
        'query': query,
    }
    return render(request, 'feedapp/all_users.html', context)
from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from .models import Studentauth, Profile, Post
from django.core.files.storage import FileSystemStorage
from django.db.models import Count

from django.conf import settings
from django.http import HttpResponse
from django.shortcuts import render, redirect

def register(request):
    if request.method == 'POST':
        email = request.POST['email']
        username = request.POST['username']
        password = request.POST['password']
        if Studentauth.objects.filter(email=email).exists():
            messages.error(request, "Email already registered")
            return redirect('register')
        user = Studentauth.objects.create_user(email=email, username=username, password=password)
        user.is_active = False
        user.save()
        Profile.objects.create(user=user)
        send_verification_email(request, user)
        messages.success(request, "Registration successful! Please check your email to activate your account.")
        return redirect('login')
    return render(request, 'feedapp/register.html')


def login_view(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        user = authenticate(request, email=email, password=password)
        if user:
            login(request, user)
            return redirect('home')
        messages.error(request, "Invalid credentials")
    return render(request, 'feedapp/login.html')

def logout_view(request):
    logout(request)
    return redirect('login')

def home(request):
    if not request.user.is_authenticated:
        return redirect('login')
    posts = Post.objects.all().order_by('-created_at')
    return render(request, 'feedapp/home.html', {'posts': posts})

def create_post(request):
    if request.method == 'POST' and request.FILES.get('image'):
        caption = request.POST['caption']
        image = request.FILES['image']
        Post.objects.create(user=request.user, caption=caption, image=image)
        return redirect('home')
    return redirect('home')

def like_post(request, post_id):
    post = Post.objects.get(id=post_id)
    if request.user in post.likes.all():
        post.likes.remove(request.user)
    else:
        post.likes.add(request.user)
    return redirect('home')

def profile(request, user_id):
    user_profile = Studentauth.objects.get(id=user_id)
    posts = Post.objects.filter(user=user_profile)
    profile_data = Profile.objects.get(user=user_profile)
    is_following = profile_data.followers.filter(id=request.user.id).exists()
    context = {
        'user_profile': user_profile,
        'posts': posts,
        'profile_data': profile_data,
        'is_following': is_following,
    }
    return render(request, 'feedapp/profile.html', context)

def follow_user(request, user_id):
    target_user = Studentauth.objects.get(id=user_id)
    target_profile = Profile.objects.get(user=target_user)
    if request.user in target_profile.followers.all():
        target_profile.followers.remove(request.user)
    else:
        target_profile.followers.add(request.user)
    return redirect('profile', user_id=user_id)
